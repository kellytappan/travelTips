***************************************************************************************************************************

Installer for MSDOS and Windows

LSI Corporation SAS3FLASH Release

***************************************************************************************************************************
=============================
Contents-
=============================
Installer for MSDOS and Windows (SAS3FLASH):

Installer for DOS(SAS3FLSH)    :  \sas3flash_dos_rel\sas3flsh           Version no:07.00.00.00     Release date:14-Aug-14
Installer for x86(SAS3FLASH)   :  \sas3flash_win_x86_rel\sas3flash      Version no:07.00.00.00     Release date:14-Aug-14
Installer for x64(SAS3FLASH)   :  \sas3flash_win_x64_rel\sas3flash      Version no:07.00.00.00     Release date:14-Aug-14

README_FOR_Installer_P6_MSDOS_and_Windows.txt

FLASH_MPT_GEN3_C0_Phase6.0-07.00.00.00.pdf

SAS2Flash_ReferenceGuide.pdf
(Applicable for SAS3FLASH)



Installation:
=============

SAS3FLASH is stand-alone binary and can be executed from any location on a file system. For more details on installer please refer to the SAS3FLASH User manual included in this package.
 




