***************************************************************************************************************************

Installer for Linux

LSI Corporation SAS3FLASH Release

***************************************************************************************************************************
=============================
Contents-
=============================
Installer for Linux (SAS3FLASH):

Installer fOr Linux (SAS3FLASH)    :  \sas3flash_linux_i686_x86-64_rel\sas3flash    Version:07.00.00.00        Release Date:14-Aug-14

Installer fOr Linux (SAS3FLASH)    :  \sas3flash_linux_ppc64_rel\sas3flash          Version:07.00.00.00        Release Date:14-Aug-14


README_FOR_Installer_P6_Linux.txt

FLASH_MPT_GEN3_C0_Phase6.0-07.00.00.00.pdf

SAS2Flash_ReferenceGuide.pdf
(Applicable for SAS3FLASH)



Installation:
=============

SAS3FLASH is stand-alone binary and can be executed from any location on a file system. For more details on installer please refer to the SAS3FLASH User manual included in this package.
 




