//
// 
// DO NOT SHUTDOWN OR RESET SYSTEM DURING FALSHING
//
//

How to flash:
1. copy Release package and contain files to USB disk.
 
2. Boot target system to UEFI Shell.

3. under Shell navigation to Release package folder.

4. execute flash.nsh batch program for auto flash BIOS.


Auto flash package list file:
1. flash tool
   isflashx64.efi

2. BIOS image file
   F006.FD 
.
3. flash script.
   FLASH.NSH

4. Help file
   Readme.txt
