//
// 
// DO NOT SHUTDOWN OR RESET SYSTEM DURING FALSHING
//
//

A:Update the BIOS under UEFI Shell
How to flash:
1. copy Release package and contain files to USB disk.
 
2. Boot target system to UEFI Shell.

3. under Shell navigation to Release package folder.

4. execute flash.nsh batch program for auto flash BIOS.


//
// 
// DO NOT SHUTDOWN OR RESET SYSTEM DURING FALSHING
//
//
B:Update BIOS under DOS
How to flash:
1. copy Release package and contain files to DOS boot disk.
 
2. Boot target system to DOS with step 1 Boot disk.

3. under DOS navigation to Release package folder.

4. execute flash.bat batch program for auto flash BIOS.


Auto flash package list file:
1. flash tool
   isflashx64.efi (for UEFI Shell environment)
   flashit.EXE (for Dos environment)

2. BIOS image file
   F007.FD 
.
3. flash script.
   FLASH.NSH (for UEFI Shell environment)
   FLASH.BAT (for Dos environment)

4. Help file
   Readme.txt
   
5. Release note
   ReleaseNotes.txt
