//
// 
// DO NOT SHUTDOWN OR RESET SYSTEM DURING FALSHING
//
//

How to flash:
1. copy Release package and contain files to DOS boot disk.
 
2. Boot target system to DOS with step 1 Boot disk.

3. under DOS navigation to Release package folder.

4. execute flash.bat batch program for auto flash BIOS.


Auto flash package list file:
1. flash tool
   flashit.EXE

2. BIOS image file
   0003.FD 
.
3. flash script.
   FLASH.BAT

4. Help file
   Readme.txt
