
The Avago/LSI Fury3008 firmware image that DDN would like flashed on the PCBAs as we indicated last week during our con call.
It is based on firmware 07000100 and has active cable management and the faceplate LED controls enabled. 
 
Please note:  We saw issues with flashing this over an earlier version of LSI firmware.  
We found that we needed to erase the Flash (sas3flash �Co �Ce 6) prior to installing the  new image.  
There were error messages, but we found the installation was incomplete if we did not erase the flash first. 
 
We have tested with FCI, Amphenol and Molex active optical SAS cables.  
The FCI and Amphenol worked as expected at 12Gb/s.  The Molex only operated at 3Gb/s.  
Avago/LSI confirmed that this is known issue with the programming of the serial EEPROM data in the Molex cables 
which they saw at a SAS plugfest late last year.
 
Thanks,
Bill
 
Bill Harker
DataDirect Networks - Technology Center
8320 Guilford Road - Suite D
Columbia, MD 21046
bharker@ddn.com
410-309-9300 x7157 (main)
410-352-7157 (direct)
 