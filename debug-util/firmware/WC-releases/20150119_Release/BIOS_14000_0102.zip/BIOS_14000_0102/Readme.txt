//
// 
// DO NOT SHUTDOWN OR RESET SYSTEM DURING FALSHING
//
//

How to flash:
How to flash:
1. copy Release package and contain files to USB boot disk.

2. Short the J41 on the board with Jumper
 
3. Boot target system to shell with step 1 Boot disk.

4. under shell navigation to Release package folder.

5. execute flash.nsh batch program for auto flash BIOS.


Auto flash package list file:
1. flash tool
   H2OFFT-Sx64.efi

2. BIOS image file
   JBL_WC_BIOS_0102.bin
.
3. flash script.
   FLASH.nsh

4. Help file
   Readme.txt
