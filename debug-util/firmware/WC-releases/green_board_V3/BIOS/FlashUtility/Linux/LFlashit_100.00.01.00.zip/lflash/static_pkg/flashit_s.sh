#!/bin/bash
ISFL_DEVNODE="/dev/isfl"
if [ "`uname -m`" == "x86_64" ]; then
	FOLDER=`pwd`/x64/
	EXEEXT=_x64
else
	FOLDER=`pwd`/IA32/
	EXEEXT=
fi

ISFL_DRV_NAME_FILE=${FOLDER}isfl_drv${EXEEXT}
ISFL_DRV_NAME=isfl_drv
ISFL_DRV_KO=$ISFL_DRV_NAME_FILE.ko

LFDD_DRV_NAME_FILE=${FOLDER}lfdd_drv
LFDD_DRV_NAME=lfdd_drv
LFDD_DRV_KO=$LFDD_DRV_NAME_FILE.ko

if [ ! -f $ISFL_DRV_KO ]; then
        cd driver/DRIVER; make; cp *.ko $FOLDER/; cd -
fi

if [ ! -f $LFDD_DRV_KO ]; then
        cd driver/Multi_FD_driver; make; cp *.ko $FOLDER/; cd -
fi


#echo $ISFL_DRV_NAME
LSMOD_ISFL=`/sbin/lsmod | grep $ISFL_DRV_NAME | cut -c -8`

FLASHTOOL=insydeflash_static${EXEEXT}_c

# Check to see isfl drvier existed
#[ "$LSMOD_ISFL" != "$ISFL_DRV_NAME" ] && insmod $ISFL_DRV_KO

if [ "$LSMOD_ISFL" = "$ISFL_DRV_NAME" ]; then
  /sbin/rmmod $ISFL_DRV_NAME
fi

/sbin/insmod $ISFL_DRV_KO

#echo $LFDD_DRV_NAME
LSMOD_LFDD=`/sbin/lsmod | grep $LFDD_DRV_NAME | cut -c -8`

if [ "$LSMOD_LFDD" = "$LFDD_DRV_NAME" ]; then
  /sbin/rmmod $LFDD_DRV_NAME
fi

/sbin/insmod $LFDD_DRV_KO
sleep 1

# Check to see isfl device node be created
[ ! -c /dev/isfl ] && mknod $ISFL_DEVNODE c 100 0
#echo $FLASHTOOL
#echo $@
#${FOLDER}$FLASHTOOL "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9"
#echo $#
#echo "$FLASHTOOL \"$1\" \"$2\" \"$3\" \"$4\" \"$5\" \"$6\" \"$7\" \"$8\" \"$9\""

if [ -a /usr/sbin/setenforce ]; then
/usr/sbin/setenforce 0
fi

if [ "$#" == 0 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL
elif [ "$#" == 1 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1"
elif [ "$#" == 2 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2"
elif [ "$#" == 3 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2" "$3"
elif [ "$#" == 4 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2" "$3" "$4"
elif [ "$#" == 5 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2" "$3" "$4" "$5"
elif [ "$#" == 6 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2" "$3" "$4" "$5" "$6"
elif [ "$#" == 7 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2" "$3" "$4" "$5" "$6" "$7"
elif [ "$#" == 8 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" 
elif [ "$#" == 9 ]; then
	LD_LIBRARY_PATH=${FOLDER} ${FOLDER}$FLASHTOOL "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9"
fi
#echo $LD_LIBRARY_PATH
exit $?

