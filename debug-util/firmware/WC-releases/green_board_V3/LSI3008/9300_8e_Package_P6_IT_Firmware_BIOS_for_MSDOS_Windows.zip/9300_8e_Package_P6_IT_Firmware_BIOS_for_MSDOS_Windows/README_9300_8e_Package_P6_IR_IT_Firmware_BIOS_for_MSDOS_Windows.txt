************************************************************************************************************************
Package for SAS3 Phase 6 Firmware BIOS Upgrade on MSDOS & Windows
************************************************************************************************************************
LSI Host Bus Adapter(HBA) - LSI SAS 9300_8e

Package Contents- 

Readme first note      :  README_9300_8e_Package_P6_IR_IT_Firmware_BIOS_for_MSDOS_Windows.txt 

Firmware               :  \firmware\SAS9300_8e_IT_ACM\SAS9300_8e_IT_ACM.bin     Version no: 06.00.00.00     Release date: 11-Aug-14
Firmware               :  \firmware\SAS9300_8e_IT\SAS9300_8e_IT.bin             Version no: 06.00.00.00     Release date: 11-Aug-14

BIOS                   :  \sasbios_rel\mptsas3.rom                              Version no: 8.13.00.00      Release date: 11-Aug-14
Readme for BIOS        :  \sasbios_rel\mptbios.txt                              Version no: NA              Release date: NA

Installer(SAS3FLSH)    :  \sas3flash_dos_rel\sas2flsh.exe                       Version no: 07.00.00.00     Release date: 14-MAY-14
Installer(SAS3FLASH)   :  \sas3flash_win_x86_rel\sas3flash.exe                  Version no: 07.00.00.00     Release date: 14-MAY-14 
Installer(SAS3FLASH)   :  \sas3flash_win_x64_rel\sas3flash.exe                  Version no: 07.00.00.00     Release date: 14-MAY-14 


Reference Guide        :  sas2flash_ReferenceGuide.pdf                          Version no: 2.1             Release date: JUNE-11
(Applicable for SAS3FLASH)

Note: SAS93xx_xxxx_xx_ACM.bin - This FW has Active Cable Management enabled feature.
----------------------------------------------------------------------------------------------------------------------------

