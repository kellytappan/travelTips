		MngDUtil Readme 
		---------------

The MngDUtil is a DOS based tool for testing the system's ASF
capabilities - both LOM or adapter. The system's capabilities include Bios 
tables parsing and validation. The adapters' testing checks the ASF 
functionalities through the SMBUS using the ICHx (2 thru 5) or NIC 
adapters (Gig). The tool leverages the Intel(R) Quartzville 
libraries: NAL, CUDL and CATL.

The tool presents the user with an interface for the different 
functions supported. There are three main components in the GUI; 
ASF functions, SMBUS functions and BIOS functions. In addition to 
the graphical interface, the application supports execution of scripts
that contain SMBUS commands.

From the main menu, the user can choose one of the following options:

A. ASF PET template

 This option allows the user to change the PET template of the PETs that are
 sent by the adapter. The affected parameters are the source NIC's IP and MAC
 addresses, as well as the IP and MAC of the proxy machine.

B. ASF SMBUS messages

 This option will open a new window with a list of Intel(R) network supported 
 adapters. (See documentation of Intel(R) Quartzville for details regarding 
 supported adapters). If the adapter is a Pro1000 brand or above, the user can 
 choose how to send the SMBUS commands: through the ICH or through the adapter 
 internal or external SMBUS). On Pro100 adapters, SMBUS transactions can only 
 be pushed through the ICH. Once the user chooses an adapter, a new window with 7 
 different ASF commands becomes available. Listed below are the commands: 
	

	1.	Push message - The tool looks for the file ASF.ini for messages.
	2.	Watchdog Start - Prompts the user for WD interval.
	3.	Watchdog Stop
	4.	Get Boot Options - Presents the supported boot options.
	5.	Clear Boot options - Clears the boot options.
	6.	Device type poll - Presents the version and functions bits.
	7.	Set System State - Prompts user for a new system state.


C. SMBus Commands

 The user can choose to send SMBUS commands either through the ICH or through 
 the adapters (above Pro1000). After the selection, the user can choose one of 
 the 5 SMBUS supported commands. All commands are executed through the ICHx. 
 The commands are:

	1.	Byte Send
	2.	Byte Read
	3.	Byte Write
	4.	Block Read
	5.	Block Write

D. ACPI / SMBios Tables

 This option will open a new menu, which includes two items: ASF! Table 
 parse, and SMBios table parse. By selecting the first option, another 
 menu will be displayed with 5 different options regarding the ASF ACPI
 table in bios. The user can choose to parse one of the following 
 sections: ASF Info, ASF Alert, ASF Remote-Control, ASF RMCP, ASF SMBUS
 Addresses. By selecting the SMBIos table parse sub-menu opens a new
 window with the information gathered from tables 1 and 129 in the BIOS.
 Note that some options might be disabled if system does not contain
 relevant BIOS information.


In addition to the GUI, the application allows the user to execute scripts
of SMBUS commands. If the application is called with a script filename in 
the command line, the SMBUS commands in the script will be executed.
The commands will be executed over the ICH controller if it is present.
The format of the script file is similar to standard batch file. The file
can contains comments (lines begin with 'REM') and empty lines. 
All commands are executed without PEC by default. In order to use PEC, the 
command line should end with 'Y' or 'y'.
The script execution will stop on the first SMBUS failure. There is an 
option to continue running the script after a failure. To enable it, the
program should be executed with the flag '/C'.

The supported commands are:

 1. blread  <SMB_slave_addr> <SMB_slave_cmd>
 2. blwrite <SMB_slave_addr> <SMB_slave_cmd> <byte_count> <data_byte 0> <data_byte 1>...
 3. bread   <SMB_slave_addr> <SMB_slave_cmd>
 4. bwrite  <SMB_slave_addr> <SMB_slave_cmd> <data_byte>
 5. bsend   <SMB_slave_addr> <SMB_slave_cmd> 
 6. brecv   <SMB_slave_addr>
 7. wread   <SMB_slave_addr> <SMB_slave_cmd>
 8. wwrite  <SMB_slave_addr> <SMB_slave_cmd> <data_word>
